// Disable prerendering for search pages since they depend on query parameters
export const prerender = false;
