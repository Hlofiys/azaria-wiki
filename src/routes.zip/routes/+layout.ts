// Enable prerendering for all pages
export const prerender = true;
